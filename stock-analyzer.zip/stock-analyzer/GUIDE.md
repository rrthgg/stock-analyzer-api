# Stock Analyzer — Guide de déploiement complet

## Architecture

```
Votre navigateur (index.html)
        |
        | fetch() HTTPS
        v
Backend FastAPI (Render.com — gratuit)
        |
        | yfinance
        v
Yahoo Finance (données temps réel, ~15 min délai)
```

---

## Étape 1 — Préparer le backend

### Structure des fichiers

```
stock-analyzer/
├── backend/
│   ├── main.py           ← le serveur API
│   ├── requirements.txt  ← dépendances Python
│   └── render.yaml       ← config déploiement Render
└── frontend/
    └── index.html        ← le site web
```

---

## Étape 2 — Déployer le backend sur Render.com (gratuit)

### 2a. Créer un compte GitHub et pusher le code

```bash
# Dans votre terminal
git init stock-analyzer-backend
cd stock-analyzer-backend

# Copiez main.py et requirements.txt dans ce dossier
# puis :
git add .
git commit -m "initial"

# Créer un repo sur github.com puis :
git remote add origin https://github.com/VOTRE_USER/stock-analyzer-backend.git
git push -u origin main
```

### 2b. Déployer sur Render

1. Allez sur https://render.com et créez un compte gratuit
2. Cliquez **New → Web Service**
3. Connectez votre repo GitHub
4. Configurez :
   - **Name** : stock-analyzer-api
   - **Environment** : Python 3
   - **Build Command** : `pip install -r requirements.txt`
   - **Start Command** : `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Plan** : Free
5. Cliquez **Create Web Service**
6. Attendez ~3 minutes — Render vous donne une URL comme :
   `https://stock-analyzer-api.onrender.com`

### 2c. Tester le backend

Ouvrez dans votre navigateur :
```
https://stock-analyzer-api.onrender.com/
→ {"status": "ok", "message": "Stock Analyzer API en ligne"}

https://stock-analyzer-api.onrender.com/stock/AAPL
→ Données complètes d'Apple en JSON
```

---

## Étape 3 — Configurer le frontend

Ouvrez `frontend/index.html` et remplacez ligne 3 du script :

```javascript
// AVANT
const API_BASE = 'https://VOTRE-API.onrender.com';

// APRÈS (avec votre vraie URL Render)
const API_BASE = 'https://stock-analyzer-api.onrender.com';
```

---

## Étape 4 — Héberger le frontend (optionnel)

### Option A — Ouvrir localement (plus simple)
Double-cliquez simplement sur `index.html` — ça fonctionne directement dans votre navigateur.

### Option B — Déployer sur GitHub Pages (gratuit, URL publique)

1. Créez un repo GitHub nommé `stock-analyzer-site`
2. Uploadez `index.html` dedans
3. Allez dans **Settings → Pages → Source : main branch**
4. Votre site sera en ligne sur :
   `https://VOTRE_USER.github.io/stock-analyzer-site`

### Option C — Déployer sur Netlify (le plus simple, drag & drop)

1. Allez sur https://netlify.com
2. Glissez-déposez votre dossier `frontend/` sur la page d'accueil
3. Votre site est en ligne en 30 secondes avec une URL Netlify

---

## Tickers supportés

### Tickers US (pas de suffixe)
```
AAPL, NVDA, MSFT, GOOGL, META, AMZN, TSLA, JPM, LLY, V, XOM...
```

### Tickers européens (suffixe obligatoire)
```
.PA  → Euronext Paris      : MC.PA, AIR.PA, TTE.PA, BNP.PA, SAN.PA
.AS  → Euronext Amsterdam  : ASML.AS, HEIA.AS
.DE  → Xetra Frankfurt     : SAP.DE, SIE.DE, ALV.DE, BMW.DE
.L   → London Stock Exch.  : AZN.L, SHEL.L, ULVR.L, HSBA.L
.MI  → Borsa Italiana      : ENEL.MI, ENI.MI, ISP.MI
.MC  → Bolsa Madrid        : ITX.MC, TEF.MC, SAN.MC (Santander)
.CO  → Nasdaq Copenhagen   : NOVO-B.CO
.SW  → SIX Swiss Exchange  : NESN.SW, NOVN.SW, ROG.SW
```

---

## Limites connues

| Limitation | Détail |
|---|---|
| Délai données | ~15 min (Yahoo Finance non-officiel) |
| Peers | Yahoo ne fournit pas de liste de pairs native |
| MACD | Calculé en approximation (MM50 vs MM200) |
| Revenu temps réel | Possible rate-limiting de Yahoo |
| Plan Render Free | Le serveur "dort" après 15 min d'inactivité (premier appel peut prendre 30–50s) |

### Solution pour le "cold start" Render

Ajoutez ce service de ping gratuit pour garder l'API éveillée :
https://uptimerobot.com — créez un moniteur HTTP vers votre URL Render toutes les 5 minutes (gratuit).

---

## Pour aller plus loin

### Données encore plus riches
Inscrivez-vous sur https://financialmodelingprep.com (plan gratuit : 250 req/jour)
et ajoutez dans `main.py` :

```python
FMP_KEY = "votre_cle_fmp"

@app.get("/stock/{ticker}/analysts")
def get_analysts(ticker: str):
    """Recommandations détaillées par banque et analyste."""
    url = f"https://financialmodelingprep.com/api/v3/analyst-stock-recommendations/{ticker}?apikey={FMP_KEY}"
    r = requests.get(url, timeout=10)
    return r.json()
```

### Cache Redis (éviter les appels répétés)
```python
# Ajoutez dans requirements.txt : redis==5.0.4
import redis, json
r = redis.from_url(os.environ.get("REDIS_URL", "redis://localhost:6379"))

# Dans get_stock() :
cached = r.get(ticker)
if cached:
    return JSONResponse(json.loads(cached))
# ... fetch ...
r.setex(ticker, 900, json.dumps(result))  # cache 15 min
```

Render propose Redis gratuit dans son dashboard.
